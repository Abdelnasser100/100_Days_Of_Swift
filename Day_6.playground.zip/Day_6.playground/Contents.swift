import UIKit
// Creating basic clouser
let driving = {
    print("i,m going to london")
}
driving()


//Accepting parameters in a closure
let driv = {(place:String) in
    print("going to \(place) in my car")
}
driv("london")

//Returning values from a closure

let drivingWithReturn = {(place:String) -> String in
    return "i'm going to \(place) in my car"
}
let message = drivingWithReturn("london")
print(message)

//Closures as parameters
/*func travel(action:()->Void){
    print("i'm getting ready to go")
    action()
    print("i arrived!")
}
travel(action: driving)
*/

//Trailing closure syntax
func travel(action: () -> Void) {
    print("I'm getting ready to go.")
    action()
    print("I arrived!")
}
travel() {
    print("I'm driving in my car")
}
travel {
    print("I'm driving in my car")
}









