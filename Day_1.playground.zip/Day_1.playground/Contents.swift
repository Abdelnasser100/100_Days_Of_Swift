import UIKit

// string
var str = "Hello, playground"
str = "Good bye"


//integer
var age = 30
var population = 8_000_000  // using under score


//Milty line in string

var str1 = """
This goes
over multiple
lines
"""
                   // to delete slath
var str2 = """
This goes\
over multiple\
lines
"""


//Double and Booleans
var pi = 3.141
var awesome = true


//string interpolation
var score = 85
var str3 = "your score was \(score)"


//Constant
let taylor = "swift"

//Type annotations
let album:String = "Reputation"
let year:Int = 1998



