import UIKit

//Protocols
/*
protocol identifiable{
    var id :String{get set}
}

struct user:identifiable{
    var id :String
}

func disPlayId(thing:identifiable){
    print("\(thing.id)")
}
*/

//Protocol inhertance

protocol playable{
    func calculateWave()->Int
}

protocol NeedsTraining{
    func study()
}

protocol Empty:playable,NeedsTraining{
    
}


//Extention

extension Int{
    func squreed() -> Int {
        return self*self
    }
}

let number = 8
number.squreed()

extension Int{
    func isEven() -> Bool {
        return self%2 == 0
    }
}



//Protocol Extention

let pythons = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"]
let beatles = Set(["John", "Paul", "George", "Ringo"])


extension Collection{
    func summerize() {
        print("\(count)")
        
        for name in self{
            print(name)
        }
    }
}

pythons.summerize()
beatles.summerize()


//Protocole Orented Programing

protocol identifiable{
    var id :String{get set}
    func identfy()
}

 extension identifiable{
    func identfy() {
        print("\(id)")
    }
}

struct user:identifiable{
    var id :String
}

let towstraws = user(id: "twastraws")
towstraws.identfy()
