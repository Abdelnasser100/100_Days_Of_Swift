import UIKit

//Array
let john = "John Lennon"
let paul = "Paul McCartney"
let george = "George Harrison"
let ringo = "Ringo Starr"

let beatles = [john, paul, george, ringo]
beatles[0]

//sets
let colors = Set(["red", "green", "blue"])
let colors2 = Set(["red", "green", "blue", "red", "blue"])     // rondom result

//tuples
var name = (first: "Taylor", last: "Swift")
name.0
name.first

//dictionary
let heights = [
    "Taylor Swift": 1.78,
    "Ed Sheeran": 1.73
]
heights["Taylor Swift"]


//dictionary defuilt value
let favoriteIceCream = [
    "Paul": "Chocolate",
    "Sophie": "Vanilla"
]
favoriteIceCream["Paul"]
favoriteIceCream["Chocolate"]
favoriteIceCream["Charlotte", default: "Unknown"]


/*creating empty collection
can create an empty dictionary with strings for keys and values like this:
*/
var teams = [String: String]()

//We can then add entries later on, like this:
teams["Paul"] = "Red"
/*Similarly, you can create an empty array to store integers like this:
*/
var result = [Int]()

//The exception is creating an empty set, which is done differently
var words = Set<String>()
var numbers = Set<Int>()

 /*you could create arrays and dictionaries with similar syntax:
*/
var scores = Dictionary<String, Int>()
var results = Array<Int>()


// Enumeration
let result1 = "failure"
let result2 = "failed"
let result3 = "fail"

enum Result {
    case success
    case failure
}
let result4 = Result.success


//Enum associated values

enum Activity {
    case bored
    case running
    case talking
    case singing
}

enum Activitys {
    case bored
    case running(destination: String)
    case talking(topic: String)
    case singing(volume: Int)
}
let talking = Activitys.talking(topic: "football")


// Enum row value

enum Planet: Int {
    case mercury
    case venus
    case earth
    case mars
}
/*Swift will automatically assign each of those a number starting from 0
*/
let earth = Planet(rawValue: 2)
/*If you want, you can assign one or more cases a specific value, and Swift will generate the rest. It’s not very natural for us to think of Earth as the second planet, so you could write this:
*/
enum Planets: Int {
    case mercury = 1
    case venus
    case earth
    case mars
}
let erarth = Planets(rawValue: 3)
/*Now Swift will assign 1 to mercury and count upwards from there, meaning that earth is now the third planet.
*/
